import Example from './components/ExampleComponent';
import Test from './components/Test';

export const routes = [
    { path: '/example', component: Example },
    { path: '/test', component: Test }
];



