
export const name = 'Mr Erp Test';

export const email = 'test@gmail.com';

export const phone = '5545454544554';
