<template>
    <div>
        <h2>Welcome to Test Component</h2>
    </div>
</template>

<script>
    export default {
        name: "Test"
    }
</script>

<style scoped>

</style>