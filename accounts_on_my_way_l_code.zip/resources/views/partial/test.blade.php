<div class="alert alert-success">
    {{ $slot }}
</div>

<div class="alert alert-danger">
    {{ $slot }}
</div>

<div class="alert alert-info">
    {{ $slot }}
</div>









