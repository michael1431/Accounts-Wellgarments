@extends('layouts.fixed')

@section('title','Company Information')

@section('content')

@stop