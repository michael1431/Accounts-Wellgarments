<?php

namespace App\Account;

use Illuminate\Database\Eloquent\Model;

class AccountCompany extends Model
{
    protected $fillable = ['name','description'];
}
