<?php

namespace App\Http\Controllers;

use App\Account\AccountLedger;
use App\Account\JournalEntrie;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Auth;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $activeUser=Auth::user();
        if(!$activeUser->active_unit){
            $activeUser->active_unit=Auth::user()->units->first()->id;
            $activeUser->update();
        }
        if(auth_unit()){
            $where=[['company_id',auth_unit()]];
        }else{
            $where=[];
        }
       
        $accountLedger = AccountLedger::where('ledger',1)->get()->count();
        $cashPayments=JournalEntrie::where('ledger_id','=',settings('cash_ledger_id'))->where('type','=',1)->where('created_at','>=', Carbon::today())->get();
        $cashReceipts=JournalEntrie::where('ledger_id','=',settings('cash_ledger_id'))->where('type','=',0)->where('created_at','>=', Carbon::today())->get();
        $bankDeposites=JournalEntrie::whereHas('acchead',function($q){
            $q->where('group_id',settings('bank_group_id'));
        })->where('type','=',0)->where('created_at','>=', Carbon::today())->get();
        $bankWithdrawns=JournalEntrie::whereHas('acchead',function($q){
            $q->where('group_id',settings('bank_group_id'));
        })->where('type','=',1)->where('created_at','>=', Carbon::today())->get();
		
        return view('dashboard.index',compact('accountLedger','cashPayments','cashReceipts','bankDeposites','bankWithdrawns'));
    }
    

    public function index2()
    {
        return view('dashboard.index2');
    }

    public function index3()
    {
        return view('dashboard.index3');
    }
}
